#include<stdio.h>

main(){

	printf ("xor =%d\n", 412525  ^ -123);
	printf ("not = %d\n" , ~412525 );
	printf ("or = %d\n", 412525 | 145);
	printf ("and = %d\n", 412525 & -23 );

}


